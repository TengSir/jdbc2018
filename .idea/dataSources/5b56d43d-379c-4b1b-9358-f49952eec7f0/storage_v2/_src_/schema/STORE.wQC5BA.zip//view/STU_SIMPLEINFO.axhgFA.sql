create view STU_SIMPLEINFO as
  select stuid,stuname from  stus where stuid>3990
/

