create PROCEDURE  pr_zhuanzhang(fromAccount in char,toAccount in char,mm  float)
AS 
BEGIN
    declare  
    begin
        update account  set money=money-mm where accno=fromAccount;
        update account  set money=money+mm where accno=toAccount;
        DBMS_OUTPUT.PUT_LINE('转账到'||toAccount||'账户'||mm||'元成功!');
        COMMIT;
        exception
        when others then
         DBMS_OUTPUT.PUT_LINE('转账失败');
        rollback;
    end;
END;
/

