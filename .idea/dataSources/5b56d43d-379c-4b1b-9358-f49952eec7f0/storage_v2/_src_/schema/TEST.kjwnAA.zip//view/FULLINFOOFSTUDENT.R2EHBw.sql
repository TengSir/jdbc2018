create view FULLINFOOFSTUDENT as
  select "TEACHERID","CLASSID","STUID","STUNAME","STUSEX","STUAGE","BIRTHDAY","PROVINCES","CITY","CLASSNAME","COUNT","TEACHERNAME","TEACHERAGE","TEACHERSEX" from stu s
inner join class c using(classid)
inner join  teacher t using(teacherid)
/

